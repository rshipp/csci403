Ryan Shipp
No challenges
Not interesting
30 minutes
