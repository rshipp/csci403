#!/usr/bin/env python
"""Convert intersections to coordinates

Requires a Google API key (in quotes) in google_secret.json.
Get a key from
https://console.developers.google.com/flows/enableapi?apiid=geocoding_backend&keyType=SERVER_SIDE&reusekey=true
"""

import json

import requests

def geocode(road1, road2):
    """Return adress from coords"""
    # read API keys
    with open('google_secret.json') as cred:
        key = json.load(cred)

    r = requests.get('https://maps.googleapis.com/maps/api/geocode/json?address={road1} and {road2}, new york city&key={key}'.format(road1=road1, road2=road2, key=key))
    r.raise_for_status()

    try:
        location = r.json()['results'][0]['geometry']['location']
        coordinates = [location['lat'], location['lng']]
    except (KeyError, IndexError):
        coordinates = []
    return coordinates

def main():
    print "var addressPoints = ["
    with open('results.csv', 'r+') as f:
        csv = f.read().strip().split('\n')
        for line in csv:
            road, crossroad, volume = line.split(',')
            try:
                lat, lng = geocode(road, crossroad)
                print '[{lat}, {lng}, "{v}"],'.format(lat=lat, lng=lng, v=volume)
            except ValueError:
                pass
    print "];"

if __name__ == "__main__":
    main()
