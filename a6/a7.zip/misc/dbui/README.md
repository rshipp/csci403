DBUI
====

Heatmap visualization

## Installation

    sudo python setup.py install

## Usage

To use Pyramid's built-in development server, run

    pserve development.ini
    
Browse to http://localhost:8080/ to see the frontend.

Note: pserve should NOT be used in a production environment. Instead, set up nginx or Apache with a `wsgi` module to serve the site.
