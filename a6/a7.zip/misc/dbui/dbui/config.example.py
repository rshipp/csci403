mongo = {
    'server': '127.0.0.1',
    'database': 'geodigger',
    'collection': 'data',
}
email = {
    'server': '',
    'username': '',
    'address': '',
    'password': '',
}
ui = {
    'tmp': '/tmp/dbui',
}
