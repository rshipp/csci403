mongo = {
    'server': '127.0.0.1',
    'database': 'geodigger',
    'collection': 'data',
}
email = {
    'server': 'smtp.gmail.com',
    'username': 'dbui',
    'address': 'dbui@gmail.com',
    'password': 'CLJ9oYQk',
}
ui = {
    'tmp': '/tmp/dbui'
}
